# Map 1-based optional input ports to variables
dataset1 <- maml.mapInputPort(1) # class: data.frame

install.packages("lpSolve")
install.packages("lpSolveAPI")
library(lpSolveAPI)

lpmodel <- make.lp(nrow = 0, ncol = 2)

#set objective direction
lp.control(lpmodel,sense='max')
    
set.objfn(lpmodel, c(1.0, 1.0))
add.constraint(lpmodel, c(2.34, 1.56), "<=", 11.3)
set.bounds(lpmodel, lower = c(1.6, 1.4), columns = c(1, 2))
set.bounds(lpmodel, upper = c(2.0, 1.8), columns = c(1, 2))
  
print(lpmodel)

solve(lpmodel)

get.objective(lpmodel)

get.variables(lpmodel)

get.constraints(lpmodel)

# Contents of optional Zip port are in ./src/
# source("src/yourfile.R");
# load("src/yourData.rdata");

# Sample operation
data.set = rbind(dataset1);

# You'll see this output in the R Device port.
# It'll have your stdout, stderr and PNG graphics device(s).
plot(data.set);

# Select data.frame to be sent to the output Dataset port
maml.mapOutputPort("data.set");